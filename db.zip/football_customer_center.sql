-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: football
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_center`
--

DROP TABLE IF EXISTS `customer_center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_center` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `content` text,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_center`
--

LOCK TABLES `customer_center` WRITE;
/*!40000 ALTER TABLE `customer_center` DISABLE KEYS */;
INSERT INTO `customer_center` VALUES (1,'<p>최저 가격Lowest Price</p><p><img src=\"http://zetta-system.iptime.org:8000/football/assets/images/img/customer-img01.png\"></p><p>- 가격 때문에 이곳 저곳 헤매지 마십시오.</p><p>- 티켓 에이전시에도 등급이 있습니다.</p><p>- 최저가격이 아니면 차액만큼 보상</p><p>1. 비교 대상 티켓 대행사 : 정식으로 등록된 에이전시(외국회사포함)라면 어디든 가능합니다.<br>2. 비교 대상 티켓 종류 : 영국 프리미어 리그만을 대상으로 합니다.(챔피언스 리그, FA컵 및 친선 경기 등은 제외)<br>3. 비교방법 : 타 싸이트에서 견적 받은 내용을 게시판 또는 이메일로 보내주시면 됩니다.<br>4. 보상신고 기간 : 구입 또는 견적 받은 시점이 일주일 이내이어야 합니다.<br>5. 보상 방법 : 담담자 접수 후 보상결정이 내려진 티켓에 대해 그 주 금요일에 고객의 구좌로 지급<br>6. 주의사항 : 가격할인 쿠폰이나 주문금액 할인쿠폰은 비교 대상에서 제외됩니다.</p><p>예약&amp;결제Reservation&amp;</p><p>- 경기에 대한 문의는 24시간 게시판 및 전화, 메일로 가능합니다.</p><p>- 예약은 예약 게시판과 전화로 가능합니다.</p><p>결제</p><p>1. 신용카드 : 영국에서 결제가 되므로 해외에서 사용 가능한 VISA또는 MasterCard를 이용해 주세요.<br><br>- 프리미어리그 티켓은 페이팔(paypal) 결제 시스템을 이용하여 결제를 진행할 수 있습니다.<br>- 신용카드 결제를 위해서 페이팔 계정 생성 및 주 사용카드 등록이 필요합니다.<br>- 카드결제 문의사항은 고객센터로 연락 바랍니다.<br><br>2. 영국 송금 계좌 번호 (카카오뱅크 등 해외 송금을 쉽게 진행할 수 있습니다) 예약 시 추가 안내 드립니다.<br>&nbsp;</p><p>환불규정</p><p>* 입금 후 관전을 취소할 경우 아래의 비율로 취소 위약금을 부과함을 알려드립니다.<br><br>* 주최 측 사정으로 경기가 연기 될 경우 50% 즉시 환불 또는 (미 확정 일정 포함)연기 된 날짜로 변경 할 수 있습니다.<br>- 이 경우 하기 환불 규정이 적용 되지 않습니다. (예) 여왕 서거로 인한 무기한 연기<br><br>* 취소 접수는 업무 시간 내 접수 및 확인이 가능합니다.<br>- (예) 평일 금요일 업무 종료 전까지 취소 하셔야 합니다. (주말 및 공휴일 취소 신청 및 적용 불가)<br><br>- 입금일 당일 통보 시 : 전액 환불<br>- 시합일 20일 전(~20)까지 통보 시 : 요금의 20% 배상<br>- 시합일 10일 전(19~10)까지 통보 시 : 요금의 30% 배상<br>- 시합일 8일 전(9~8)까지 통보 시 : 요금의 45% 배상<br>- 시합일 1일 전(7~1)까지 통보 시 : 요금의 60% 배상<br>- 시합일 통보 시 : 전액 환불 불가<br>&nbsp;</p><p>티켓수령</p><p>- 대부분의 경기 티켓은 경기 당일로부터 1~2일 내 메일로 e티켓이 전달 됩니다.<br>- 일부 경기의 경우 수령 및 반납이 필요한 전자카드로 진행 될 수 있으며 이 경우 추가 안내 드립니다.</p>');
/*!40000 ALTER TABLE `customer_center` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 12:55:04
