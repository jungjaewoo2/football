-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: football
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `qna`
--

DROP TABLE IF EXISTS `qna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `qna` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `parent_post_id` int DEFAULT NULL,
  `regdate` datetime(6) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `notice` varchar(1) DEFAULT 'N',
  `ref` int DEFAULT '0',
  `passwd` varchar(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6785 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qna`
--

LOCK TABLES `qna` WRITE;
/*!40000 ALTER TABLE `qna` DISABLE KEYS */;
INSERT INTO `qna` VALUES (6780,'dfsfsdfdsfdsf\r\nsdfsdf\r\nsadafsdaf\r\nsdfs\r\ndsfadsf\r\ndsf\r\ndsf\r\ndsf\r\ndsfdsfdsaf,dfsfsdfdsfdsf\r\nsdfsdf\r\nsadafsdaf\r\nsdfs\r\ndsfadsf','2025-07-16 18:49:49.813748','정재우',NULL,'2025-07-16 18:49:49.813748','티켓문의,티켓문의','2025-07-16 18:57:20.772406',NULL,'N',3,'1234'),(6781,'sdfdsfdsfdsafdasf\r\nsadfsadfsdafdsaf\r\ndf\r\nasdfsdaf','2025-07-16 19:00:05.270303','정재우',NULL,'2025-07-16 19:00:05.270303','티켓문의2','2025-07-16 19:00:05.270303',NULL,'N',3,'1234'),(6783,'ddfdsfs\r\nsdf\r\nsdf\r\nsdf\r\nsdf\r\nsdfs\r\nㅇㄹㅇㄹㅇㅇㄹㅇㄹㅇdddddddd\r\nㅇ\r\nㄹㄴㅇㄹㅇ\r\nㄹㅇㄹㅇ','2025-07-16 19:31:22.767864','정재우',NULL,'2025-07-16 19:31:22.767864','티켓문의','2025-07-17 11:04:58.201456',NULL,'N',10,'1234'),(6784,'닫변릉 확인\r\n확인바랍니다','2025-07-17 04:55:33.144124','관리자',6783,'2025-07-17 04:55:33.191997','답변','2025-07-17 04:55:33.144124',NULL,'N',0,'admin');
/*!40000 ALTER TABLE `qna` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 12:55:05
