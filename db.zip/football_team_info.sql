-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: football
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team_info`
--

DROP TABLE IF EXISTS `team_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_info` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `city` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `logo_img` varchar(255) DEFAULT NULL,
  `seat_img` varchar(255) DEFAULT NULL,
  `stadium` varchar(255) DEFAULT NULL,
  `team_name` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=4334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_info`
--

LOCK TABLES `team_info` WRITE;
/*!40000 ALTER TABLE `team_info` DISABLE KEYS */;
INSERT INTO `team_info` VALUES (4324,'Manchester',NULL,'logo_62ea609d-9b6e-42c4-b17e-f0c19af3c5f9.jpg','seat_b4ef9b04-328e-4f27-ac0f-56d325812cfb.jpg','Old Trafford','Manchester United',NULL,''),(4325,'Liverpool',NULL,'logo_987c5398-03df-47ed-a751-9dc185fd77fa.jpg',NULL,'Anfield','리버풀 LIVERPOOL',NULL,''),(4326,'London',NULL,'logo_6f219db7-cec1-417b-a585-c88175e946d8.jpg',NULL,'Emirates Stadium','맨유 MANCHESTER UTD',NULL,''),(4327,'Madrid',NULL,'logo_c6aa037a-6c0d-46bd-a6c2-a6672f083ccd.jpg',NULL,'Santiago Bernabéu','맨시티 MANCHESTER CITY',NULL,''),(4328,'Barcelona',NULL,'logo_c9162de2-fab1-4183-b97e-0fcbf3c9dabc.jpg',NULL,'Camp Nou','아스날 ARSENAL',NULL,''),(4329,'영국',NULL,'logo_56388d99-da0d-425e-a68b-bbdface9cec8.jpg',NULL,'Allianz Arena','토트넘 TOTTENHAM',NULL,'ㅇㄹㅇㄹㅇㄹㅇㄹㅇㄹ'),(4330,'Dortmund',NULL,'logo_38d71e11-af1f-474e-845e-58156a5502c8.jpg',NULL,'Signal Iduna Park','첼시 CHELSEA',NULL,'ㅇㄹㅇㄹㅇㄹㅇㄹㅇㄹㅇ'),(4331,'영국',NULL,'logo_d9de2b9c-1f96-4c93-b571-32a1f3d21048.jpg',NULL,'Parc des Princes','리버풀 LIVERPOOL',NULL,'ㅇㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹ'),(4333,'영국',NULL,'logo_d74f421c-803e-427a-aab2-3538d8aed8d9.jpg','seat_6bd1ccdb-a93a-4817-8770-67522733da1c.jpg','맨유 경기장','맨유 MANCHESTER UTD',NULL,'ㅇㄹㅇㄹㅇㄹㄴㄹㄴㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹㄴㅇㄹㅇㄴㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹㄴㅇㄹ');
/*!40000 ALTER TABLE `team_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 12:55:04
