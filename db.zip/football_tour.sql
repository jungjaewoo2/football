-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: football
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tour`
--

DROP TABLE IF EXISTS `tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tour` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `content` text,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour`
--

LOCK TABLES `tour` WRITE;
/*!40000 ALTER TABLE `tour` DISABLE KEYS */;
INSERT INTO `tour` VALUES (1,'<h2><img src=\"http://zetta-system.iptime.org:8000/football/assets/images/about/about-img01.png\" alt=\"about-thumb\"><br>&nbsp;</h2><h2><strong>믿을 수 있는 여행사</strong></h2><p>유로풋볼투어는 결제 당일 서비스 항목에 대한 증빙서류 제공을 원칙으로 합니다.<br>항공의 경우 결제 당일 발권, e티켓을 제공하며 해당 항공사 홈페이지에서 실제 예약 유무를 직접 확인 할 수 있습니다.<br>숙소 및 축구 티켓 등 겨제 후 서비스 업체로부터 예약 확인증을 발급받아 결제 당일 전달드립니다.</p><h2><strong>원칙을 지키는 여행사</strong></h2><p>유로풋볼투어는 여행자의 목적에 맞는 여행상품을 기획하고 여행 전 계약서를 배부 및 서명 합니다.<br>소액의 계약금을 포함한 계약에 필요한 필수 항목 결제 후 확인증을 배부합니다.<br>여행 한달 전 잔금을 결제하며 그 사이 에치금 또는 임치(任置)에 필요한 금액을 요구하지 않습니다.</p><h2><strong>안전한 여행사</strong></h2><p>유로풋볼투어는 법령에 의거하여 여행자 보증보험을 1년마다 갱신합니다.<br>여행자는 계약한 서비스를 제공받지 못한 경우 최고 3천만원 한도에서 보상받으실 수 있습니다.<br>한편 여행 시 발생할 수 있는 불의의 상황을 대비하여 모든 여행자들은 여행자 보험에 가입합니다.<br>보험은 상해 및 병원 진료 시 기준에 맞춰 보상 받을 수 있습니다.</p>');
/*!40000 ALTER TABLE `tour` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 12:55:05
