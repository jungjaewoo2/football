-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: football
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `register_schedule`
--

DROP TABLE IF EXISTS `register_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `additional_requests` text,
  `adjacent_seat` varchar(255) NOT NULL,
  `away_team` varchar(255) NOT NULL,
  `companions` text,
  `created_at` datetime(6) DEFAULT NULL,
  `customer_address` varchar(255) NOT NULL,
  `customer_address_detail` varchar(255) NOT NULL,
  `customer_birth` date NOT NULL,
  `customer_detail_address` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_english_address` varchar(255) NOT NULL,
  `customer_gender` varchar(255) NOT NULL,
  `customer_kakao_id` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_passport` varchar(255) NOT NULL,
  `customer_phone` varchar(255) NOT NULL,
  `game_date` varchar(255) NOT NULL,
  `game_time` varchar(255) NOT NULL,
  `home_team` varchar(255) NOT NULL,
  `payment_method` varchar(255) NOT NULL,
  `seat_alternative` varchar(255) NOT NULL,
  `seat_price` varchar(255) NOT NULL,
  `selected_color` varchar(255) NOT NULL,
  `ticket_quantity` int NOT NULL,
  `total_price` varchar(255) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `approval_status` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `reservation_status` varchar(255) NOT NULL,
  `register_ok` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register_schedule`
--

LOCK TABLES `register_schedule` WRITE;
/*!40000 ALTER TABLE `register_schedule` DISABLE KEYS */;
INSERT INTO `register_schedule` VALUES (1,'테스트 예약','아니오','첼시',NULL,'2025-07-13 11:40:33.000000','12345','서울시 강남구','1990-01-01','123-456','test@test.com','Seoul Gangnam-gu','남','testkakao','테스트','TEST KIM','010-1234-5678','2025-07-15','16:30','맨유','신용카드','아니오','320000','yellow',1,'320000','test-001','2025-07-16 05:53:45.643384','승인완료','결제완료','예약완료','Y'),(5,'창가 자리 부탁드립니다','필요','리버풀','[]','2025-07-14 15:29:41.000000','서울특별시','강남구','1990-01-15','테헤란로 123','kim@test.com','123 Teheran-ro, Gangnam-gu, Seoul','남성','kimchulsoo','김철수','M12345678','010-1234-5678','2024-03-15','20:30','맨체스터 유나이티드','신용카드','가능','150,000','레드',2,'300,000','user001','2025-07-14 06:42:12.250832','미승인','결제대기','예약완료','Y'),(6,'','불필요','첼시','[]','2025-07-14 15:30:10.000000','부산광역시','해운대구','1992-05-20','해운대로 456','lee@test.com','456 Haeundae-ro, Haeundae-gu, Busan','여성','leeyounghee','이영희','F23456789','010-2345-6789','2024-03-16','21:00','아스널','계좌이체','불가능','180,000','블루',1,'180,000','user002','2025-07-14 15:30:10.000000','승인','결제완료','예약완료','Y'),(7,'좋은 자리로 부탁드립니다.','Y','리버풀','[{\"name\":\"김철수 동행자\",\"passport\":\"M8765432101\",\"phone\":\"010-2345-6789\"}]','2025-07-16 02:04:41.775106','서울특별시 강남구 테헤란로 123','1동 101호','1985-01-01','상세주소 1','customer1@football.com','English Address 1','남성','kakao1','김철수','M1234567801','010-1234-5678','2024-01-15','20:00','맨체스터 유나이티드','신용카드','Y','50,000원','빨강',1,'50000','UID000001','2025-07-16 02:04:41.775106','대기중','미결제','예약대기','N'),(8,'좋은 자리로 부탁드립니다.','Y','아스널','','2025-07-16 02:04:41.965121','서울특별시 서초구 서초대로 456','2동 202호','1986-02-02','상세주소 2','customer2@football.com','English Address 2','여성','kakao2','이영희','M1234567802','010-2345-6789','2024-01-22','19:30','첼시','계좌이체','Y','50,000원','파랑',2,'100000','UID000002','2025-07-16 02:04:41.965121','승인완료','결제완료','예약완료','Y'),(9,'좋은 자리로 부탁드립니다.','Y','토트넘','[{\"name\":\"박민수 동행자\",\"passport\":\"M8765432103\",\"phone\":\"010-4567-8901\"}]','2025-07-16 02:04:41.992049','서울특별시 송파구 올림픽로 789','3동 303호','1987-03-03','상세주소 3','customer3@football.com','English Address 3','남성','kakao3','박민수','M1234567803','010-3456-7890','2024-01-29','21:00','맨체스터 시티','신용카드','Y','50,000원','초록',3,'150000','UID000003','2025-07-16 11:33:08.075574','승인완료','결제완료','예약완료','Y'),(10,'좋은 자리로 부탁드립니다.','Y','웨스트햄','','2025-07-16 02:04:42.021972','서울특별시 마포구 와우산로 321','4동 404호','1988-04-04','상세주소 4','customer4@football.com','English Address 4','여성','kakao4','최지영','M1234567804','010-4567-8901','2024-02-05','20:00','에버튼','계좌이체','Y','50,000원','빨강',1,'50000','UID000004','2025-07-16 02:04:42.021972','승인완료','결제완료','예약완료','Y'),(11,'좋은 자리로 부탁드립니다.','Y','브라이튼','[{\"name\":\"정현우 동행자\",\"passport\":\"M8765432105\",\"phone\":\"010-6789-0123\"}]','2025-07-16 02:04:42.048896','서울특별시 종로구 종로 654','5동 505호','1989-05-05','상세주소 5','customer5@football.com','English Address 5','남성','kakao5','정현우','M1234567805','010-5678-9012','2024-02-12','19:30','뉴캐슬','신용카드','Y','50,000원','파랑',2,'100000','UID000005','2025-07-16 02:04:42.048896','대기중','미결제','예약대기','N'),(12,'좋은 자리로 부탁드립니다.','Y','번리','','2025-07-16 02:04:42.091814','서울특별시 용산구 이태원로 987','6동 606호','1990-06-06','상세주소 6','customer6@football.com','English Address 6','여성','kakao6','한소영','M1234567806','010-6789-0123','2024-02-19','21:00','크리스탈 팰리스','계좌이체','Y','50,000원','초록',3,'150000','UID000006','2025-07-16 07:25:23.029617','승인완료','결제완료','예약완료','Y'),(13,'좋은 자리로 부탁드립니다.','Y','아스톤 빌라','[{\"name\":\"윤태호 동행자\",\"passport\":\"M8765432107\",\"phone\":\"010-8901-2345\"}]','2025-07-16 02:04:42.141648','서울특별시 영등포구 여의대로 147','7동 707호','1991-07-07','상세주소 7','customer7@football.com','English Address 7','남성','kakao7','윤태호','M1234567807','010-7890-1234','2024-02-26','20:00','울버햄튼','신용카드','Y','50,000원','빨강',1,'50000','UID000007','2025-07-16 02:04:42.141648','승인완료','결제완료','예약완료','Y'),(14,'좋은 자리로 부탁드립니다.','Y','풀럼','','2025-07-16 02:04:42.193507','서울특별시 광진구 능동로 258','8동 808호','1992-08-08','상세주소 8','customer8@football.com','English Address 8','여성','kakao8','임수진','M1234567808','010-8901-2345','2024-03-05','19:30','브렌트포드','계좌이체','Y','50,000원','파랑',2,'100000','UID000008','2025-07-16 07:19:44.743010','승인완료','결제완료','예약완료','Y'),(15,'좋은 자리로 부탁드립니다.','Y','본머스','[{\"name\":\"강동원 동행자\",\"passport\":\"M8765432109\",\"phone\":\"010-0123-4567\"}]','2025-07-16 02:04:42.260332','서울특별시 성동구 왕십리로 369','9동 909호','1993-09-09','상세주소 9','customer9@football.com','English Address 9','남성','kakao9','강동원','M1234567809','010-9012-3456','2024-03-12','21:00','노팅엄 포레스트','신용카드','Y','50,000원','초록',3,'150000','UID000009','2025-07-16 02:04:42.260332','승인완료','결제완료','예약완료','Y'),(17,'ㄴㅇㄹㅇㄴㄹdfsㄴㅇㅁㄹㅇㅁㄴ','아니오','맨시티 MANCHESTER CITY','[{\"name\":\"정재일\",\"birth\":\"2025-07-16\",\"gender\":\"남\"},{\"name\":\"정재이\",\"birth\":\"2025-07-17\",\"gender\":\"여\"},{\"name\":\"정재삼\",\"birth\":\"2025-07-31\",\"gender\":\"남\"}]','2025-07-17 17:22:48.855564','02776','서울 성북구 돌곶이로 88-18','2025-07-16','5','comsa330@naver.com','jugn ddfd dgggdf 345','여','topy','정재우1','jung jaewoo','01023232','2025-07-19','19:00','Manchester United','신용카드','아니오','1000','orange',4,'4,000원','3','2025-07-17 18:04:26.025500','미승인','결제대기','예약완료','Y');
/*!40000 ALTER TABLE `register_schedule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 12:55:03
